// Business and advertising management
class BusinessManager {
  constructor() {
    this.businesses = JSON.parse(localStorage.getItem('businesses')) || [];
    this.initializeEventListeners();
    this.renderBusinesses();
  }

  initializeEventListeners() {
    const advertiseForm = document.getElementById('advertise-form');
    if (advertiseForm) {
      advertiseForm.addEventListener('submit', this.handleAdvertiseSubmit.bind(this));
    }

    const categoryCards = document.querySelectorAll('.category-card');
    categoryCards.forEach(card => {
      card.addEventListener('click', () => this.filterBusinessesByCategory(card.dataset.category));
    });
  }

  handleAdvertiseSubmit(e) {
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form);

    const newBusiness = {
      id: Date.now(),
      name: formData.get('businessName'),
      category: formData.get('category'),
      description: formData.get('description'),
      email: formData.get('email'),
      phone: formData.get('phone')
    };

    // Handle image upload
    const imageFile = formData.get('businessImage');
    if (imageFile && imageFile.size > 0) {
      const reader = new FileReader();
      reader.onload = (event) => {
        newBusiness.imageUrl = event.target.result;
        this.addBusiness(newBusiness);
      };
      reader.readAsDataURL(imageFile);
    } else {
      this.addBusiness(newBusiness);
    }

    form.reset();
    alert('Anúncio enviado com sucesso!');
  }

  addBusiness(business) {
    this.businesses.push(business);
    localStorage.setItem('businesses', JSON.stringify(this.businesses));
    this.renderBusinesses();
  }

  renderBusinesses(filteredCategory = null) {
    const businessGrid = document.querySelector('.business-grid');
    if (!businessGrid) return;

    businessGrid.innerHTML = '';

    const displayBusinesses = filteredCategory 
      ? this.businesses.filter(b => b.category === filteredCategory)
      : this.businesses;

    displayBusinesses.forEach(business => {
      const businessCard = document.createElement('div');
      businessCard.className = 'business-card';
      businessCard.dataset.category = business.category;

      const image = document.createElement('img');
      image.src = business.imageUrl || 'https://via.placeholder.com/150';
      image.alt = business.name;

      const title = document.createElement('h3');
      title.textContent = business.name;

      const description = document.createElement('p');
      description.textContent = business.description;

      const detailsButton = document.createElement('a');
      detailsButton.href = '#';
      detailsButton.className = 'details-button';
      detailsButton.textContent = 'Ver Detalhes';

      businessCard.append(image, title, description, detailsButton);
      businessGrid.appendChild(businessCard);
    });
  }

  filterBusinessesByCategory(category) {
    // Highlight selected category
    const categoryCards = document.querySelectorAll('.category-card');
    categoryCards.forEach(card => {
      card.classList.toggle('highlight', card.dataset.category === category);
    });

    this.renderBusinesses(category);
  }
}

// Smooth scroll and other existing functionality
document.addEventListener('DOMContentLoaded', () => {
  const contactForm = document.querySelector('.contact-form');
  
  contactForm.addEventListener('submit', (e) => {
    e.preventDefault();
    alert('Mensagem enviada com sucesso! Em breve entraremos em contato.');
    contactForm.reset();
  });

  // Existing smooth scroll code
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      document.querySelector(this.getAttribute('href')).scrollIntoView({
        behavior: 'smooth'
      });
    });
  });

  // Initialize Business Manager
  new BusinessManager();

  // Feather Icons
  feather.replace();
});